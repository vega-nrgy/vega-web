/**
 * Vega Charge — Line-Flow Logo Loader
 * Standalone init function. Call vegaInitLoader() once the DOM is ready.
 *
 * Markup contract (see loader.html):
 *   #vega-loader
 *     svg.vega-logo-trace
 *       path#vegaTopPath.vega-trace-path.vega-trace-top
 *       path#vegaBottomPath.vega-trace-path.vega-trace-bottom
 *
 * HIDE_DELAY_MS should match (or exceed) the CSS animation duration (5s)
 * plus a small buffer. In production, replace the fixed timeout with a
 * real "assets ready" signal (e.g. Promise.all of critical image/font
 * loads) and only start the fade-out once both are true — whichever
 * finishes last.
 */
function vegaInitLoader({ hideDelayMs = 5300 } = {}) {
  const loader = document.getElementById('vega-loader');
  if (!loader) return;

  ['vegaTopPath', 'vegaBottomPath'].forEach((id) => {
    const path = document.getElementById(id);
    if (!path) return;
    const len = path.getTotalLength();
    path.style.setProperty('--len', len);
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
  });

  setTimeout(() => {
    loader.classList.add('hide');
  }, hideDelayMs);
}

// Auto-init if loaded directly via <script src="loader.js"> after the markup.
// Remove this line if you prefer to call vegaInitLoader() manually from
// your app's mount/ready lifecycle (e.g. React useEffect, Vue onMounted).
document.addEventListener('DOMContentLoaded', () => vegaInitLoader());
