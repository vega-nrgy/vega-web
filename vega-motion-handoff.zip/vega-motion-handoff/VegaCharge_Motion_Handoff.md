# Vega Charge — Motion Components Handoff
Prepared for implementation in Claude Code. Two standalone, framework-agnostic components: a logo line-flow loader, and a scroll-pinned day/night hero transition.

Stack-agnostic on purpose — everything is plain HTML/CSS/JS so it can be ported into whatever the live site actually runs on (React, Next.js, plain static, etc). If the target stack is component-based, wrap each `.html/.css/.js` trio into a component and call the init function (`vegaInitLoader()` / `vegaInitHero()`) in the appropriate lifecycle hook (`useEffect`, `onMounted`, etc.) instead of relying on the `DOMContentLoaded` auto-init.

---

## 1. File manifest

```
vega-motion-handoff/
├── VegaCharge_Motion_Handoff.md   ← this file
├── loader/
│   ├── loader.css
│   ├── loader.js
│   └── preview.html               ← standalone runnable demo
├── hero/
│   ├── hero.css
│   ├── hero.js
│   └── preview.html               ← standalone runnable demo
└── assets/
    ├── hero-night.jpg             ← compressed placeholder (real render provided by client)
    └── hero-day.jpg               ← compressed placeholder (real studio shot provided by client)
```

Open `loader/preview.html` or `hero/preview.html` directly in a browser to see each in isolation before wiring into the real site.

---

## 2. Component 1 — Line-flow logo loader

### What it does
Two SVG paths (top half / bottom half of the Vega Charge mark) draw themselves in from left to right using the classic `stroke-dasharray` / `stroke-dashoffset` technique, hold fully formed with a soft teal glow pulse and wordmark fade-in, then continue past their own length so they "erase" from the left — reading as the line flowing onward and off the right edge. Total cycle: 5s, then the loader fades out.

### Traced logo geometry — IMPORTANT
The path coordinates below were extracted programmatically (OpenCV contour detection, not eyeballed) from the client-provided logo PNG (130×158px source). They trace the **outer silhouette only** of each half — the small triangular notch where the mark's internal hexagonal hole cuts into each half was simplified out for a cleaner line-flow read.

- **Top half ("A")**: `M19,77 L66,30 L91,27 L91,76`
- **Bottom half ("V")**: `M42,79 L42,128 L65,126 L113,78`

**Before shipping this to production, replace these with the real vector path data from the client's actual logo `.svg`/`.ai` source file if available** — this was traced from a raster export, so it's accurate to that specific PNG but not guaranteed pixel-perfect to the master vector. If the client can provide the source file, re-run the same contour-trace approach (or just copy the real `<path d="...">` data directly) and swap it into `loader.css`'s markup contract (see `preview.html`).

### Key implementation detail
`loader.js` measures each path's real length via `path.getTotalLength()` at runtime and sets a `--len` CSS custom property, which the keyframes in `loader.css` reference via `calc(var(--len) * ...)`. **Do not hardcode dasharray/dashoffset values** — the whole technique depends on measuring the actual rendered path length, which will differ if the SVG viewBox or path data changes.

### Known TODOs / open decisions
- **Timing**: 5s total is deliberately generous for review purposes. Production should either compress to ~1.5–2s, or better, tie the "hold" duration to real asset-load completion (`Promise.all` of critical images/fonts) rather than a fixed timer — see the comment in `loader.js`.
- **Notch fidelity**: if the client wants the internal notch reflected in the line trace (not just the outer silhouette), the path data needs 2-3 more points per half — flag this back if it matters visually at the loader's small size.
- **Stroke joins**: currently `round` linecap/linejoin for a softer flowing feel. The real logo uses sharp/mitered corners — swap to `miter`/`butt` if brand consistency at this size matters more than the flow aesthetic.

---

## 3. Component 2 — Scroll-pinned hero (night → day wipe)

### What it does
The hero section pins (`position: sticky`) for 3 viewport-heights of scroll distance. As the user scrolls through it, a diagonal `clip-path` wipe reveals the daylight charger photo from behind the night station photo, while the headline/copy crossfades from teal-on-navy ("Charging India Forward") to navy-on-white ("Every stop, a promise kept").

### Known gotcha already hit once — do not reintroduce
**Do not set `overflow-x: hidden` on `html`/`body`** anywhere in the page this gets embedded into. It breaks `position: sticky` in most browsers by turning `<body>` into its own scroll container instead of letting the viewport drive the sticky calculation. If horizontal overflow needs containing, apply `overflow-x: hidden` to a wrapper `<div>` that does **not** contain the sticky hero, or use `overflow: clip` on that wrapper instead.

### Images
`assets/hero-night.jpg` and `assets/hero-day.jpg` are compressed placeholders derived from the client's uploaded reference renders (resized to 900px wide, ~65% JPEG quality, to keep the prototype light). **Swap these for full-resolution production assets** before shipping — current files are demo-weight only, not export-ready.

### Known TODOs / open decisions
- **Wipe angle/style**: current diagonal cut is intentionally punchy for a clear demo. A softer blur-crossfade or curtain-style wipe may read as more premium — worth A/B'ing once real content is in place.
- **Day/night narrative vs. time-of-day**: this is currently a pure scroll-driven story (dusk → resolved daylight trust). If the client also wants the hero to reflect the visitor's actual local time of day, that's a different (simpler) implementation — a straight crossfade with no scroll dependency — and the two ideas shouldn't be conflated.
- **Scroll distance** (`.vega-hero-pin { height: 300vh }`): tune this against real content length; too short and the wipe feels rushed, too long and users scroll past it without noticing.

---

## 4. Brand tokens referenced

```css
--vega-navy-deep: #020c10;
--vega-navy:      #04141a;
--vega-teal:      #1ce8a6;
--vega-teal-dim:  #0f6e56;
--vega-white:     #f5f7f6;
```

These were sampled from the client's uploaded brand/logo reference images — confirm against the actual brand guideline doc/Figma if one exists, as these are close approximations, not extracted from a color-managed source.

---

## 5. Suggested next steps in Claude Code

1. Integrate both components into the actual site's component structure (React components, or plain includes, depending on stack).
2. Replace the loader's traced path data with real vector source if/when available.
3. Replace hero placeholder images with production-resolution assets.
4. Wire `vegaInitLoader()` to real asset-readiness rather than a fixed timer.
5. Cross-browser check the hero's `position: sticky` behavior, especially Safari.
