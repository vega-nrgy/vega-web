/**
 * Vega Charge — Scroll-Pinned Hero: Night → Day Diagonal Wipe
 * Standalone init function. Call vegaInitHero() once the DOM is ready.
 *
 * Markup contract (see hero.html):
 *   .vega-hero-pin
 *     .vega-hero-frame
 *       .vega-hero-layer.night
 *       .vega-hero-layer.day   #vegaDayLayer
 *       .vega-hero-overlay
 *       .vega-hero-copy        #vegaNightCopy
 *       .vega-hero-copy.day-copy #vegaDayCopy
 */
function vegaInitHero() {
  const pin = document.getElementById('vegaHeroPin');
  const day = document.getElementById('vegaDayLayer');
  const nightCopy = document.getElementById('vegaNightCopy');
  const dayCopy = document.getElementById('vegaDayCopy');
  if (!pin || !day) return;

  function clipForProgress(p) {
    const e = Math.max(0, Math.min(1, p));
    const spread = 140 * e;
    return `polygon(0 0, ${spread}% 0, ${Math.max(0, spread - 25)}% 100%, 0 100%)`;
  }

  function onScroll() {
    const rect = pin.getBoundingClientRect();
    const total = pin.offsetHeight - window.innerHeight;
    const scrolled = Math.min(Math.max(-rect.top, 0), total);
    const progress = total > 0 ? scrolled / total : 0;

    day.style.clipPath = clipForProgress(progress * 1.3);
    if (nightCopy) nightCopy.style.opacity = String(Math.max(0, 1 - progress * 2.2));
    if (dayCopy) dayCopy.style.opacity = String(Math.max(0, (progress - 0.55) * 2.6));
  }

  document.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

document.addEventListener('DOMContentLoaded', () => vegaInitHero());
